<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserAccess;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    /**
     * Register new user and create access record
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string|max:50',
            'lastname' => 'required|string|max:50',
            'gender' => 'required|in:M,F,O',
            'phone' => 'required|string|max:15|unique:users,phone',
            'email' => 'required|email|max:100|unique:users,email',
            'password' => 'required|string|min:8',
            'role' => 'required|string|in:user,admin,staff',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Validation failed',
                'errors' => $validator->errors(),
                'code' => 422
            ], 422);
        }

        try {
            $user = User::create($request->only([
                'firstname', 'lastname', 'gender', 'phone', 'email'
            ]));

            UserAccess::create([
                'usercode' => $user->usercode,
                'role' => $request->role,
                'password' => Hash::make($request->password),
            ]);

            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'success' => true,
                'message' => 'User registered successfully',
                'user' => $user->load('access'),
                'token' => $token,
                'code' => 201
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Server error: ' . $e->getMessage(),
                'code' => 500
            ], 500);
        }
    }

    /**
     * Login existing user
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => 'Validation failed',
                'errors' => $validator->errors(),
                'code' => 422
            ], 422);
        }

        $user = User::with('access')->where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->access->password)) {
            return response()->json([
                'success' => false,
                'error' => 'Invalid credentials',
                'code' => 401
            ], 401);
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Login successful',
            'user' => $user->load('access'),
            'token' => $token,
            'code' => 200
        ]);
    }

    /**
     * Logout (revoke token)
     */
    public function logout(Request $request)
    {
        try {
            $request->user()->tokens()->delete();

            return response()->json([
                'success' => true,
                'message' => 'Logged out successfully',
                'code' => 200
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Logout failed: ' . $e->getMessage(),
                'code' => 500
            ], 500);
        }
    }
}
