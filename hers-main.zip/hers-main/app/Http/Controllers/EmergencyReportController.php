<?php

namespace App\Http\Controllers;

use App\Models\EmergencyReport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EmergencyReportController extends Controller
{
    /**
     * Create new emergency report
     */
    public function sendReport(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:accident,medical,other',
            'severity' => 'required|in:critical,moderate,low',
            'number_of_victims' => 'required|integer|min:1',
            'description' => 'nullable|string',
            'location' => 'required|string',
            'location_lat' => 'required|numeric',
            'location_lng' => 'required|numeric',
        ]);

        try {
            $report = EmergencyReport::create([
                ...$validated,
                'reported_by' => Auth::user()->usercode,
                'status' => 'pending',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Emergency report submitted successfully.',
                'data' => $report,
                'code' => 201
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to submit emergency report.',
                'details' => $e->getMessage(),
                'code' => 500
            ], 500);
        }
    }

    /**
     * List all reports for the logged-in user
     */
    public function myReports()
    {
        try {
            $reports = EmergencyReport::where('reported_by', Auth::user()->usercode)
                ->orderByDesc('created_at')
                ->get();

            return response()->json([
                'success' => true,
                'message' => 'Your emergency reports retrieved successfully.',
                'data' => $reports,
                'code' => 200
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Unable to retrieve reports.',
                'details' => $e->getMessage(),
                'code' => 500
            ], 500);
        }
    }

    /**
     * View single report details
     */
//    public function getReport(Request $request)
//    {
//        $report_id = $request->report_id;
//
////        $report = EmergencyReport::where('report_id', $report_id)
////            ->where('reported_by', Auth::user()->usercode)
////            ->first();
//        $report =  EmergencyReport::with(['reporter', 'patients'])
//            ->where('reported_by', Auth::user()->usercode)
//            ->get();
//
//        if (!$report) {
//            return response()->json([
//                'success' => false,
//                'error' => 'Report not found or unauthorized.',
//                'code' => 404
//            ], 404);
//        }
//
//        return response()->json([
//            'success' => true,
//            'message' => 'Report retrieved successfully.',
//            'data' => $report,
//            'code' => 200
//        ], 200);
//    }

    public function getReport(Request $request)
    {
        $report_id = $request->report_id;

        $report = EmergencyReport::with(['reporter', 'patients'])
            ->where('report_id', $report_id)
            ->first();

        if (!$report) {
            return response()->json([
                'success' => false,
                'error' => 'Report not found or unauthorized.',
                'code' => 404
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Report retrieved successfully.',
            'data' => $report, // single object, not array
            'code' => 200
        ], 200);
    }


    /**
     * View all reports (for admin)
     */
    public function getAllReports(Request $request)
    {
        try {
            $reports = EmergencyReport::with(['reporter', 'patients'])
                ->orderBy('created_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'message' => 'All emergency reports retrieved successfully.',
                'data' => $reports,
                'code' => 200
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to fetch reports.',
                'details' => $e->getMessage(),
                'code' => 500
            ], 500);
        }
    }

    /**
     * Update emergency report status
     */
    public function updateStatus(Request $request)
    {
        $request->validate([
            'report_id' => 'required|string|exists:emergency_reports,report_id',
            'status' => 'required|in:pending,acknowledge,dispatched,resolved',
        ]);

        $report = EmergencyReport::where('report_id', $request->report_id)->first();

        if (!$report) {
            return response()->json([
                'success' => false,
                'error' => 'Emergency report not found.',
                'code' => 404
            ], 404);
        }

        $oldStatus = $report->status;
        $report->status = $request->status;
        $report->save();

        return response()->json([
            'success' => true,
            'message' => "Report status updated from '{$oldStatus}' to '{$report->status}'.",
            'data' => $report,
            'code' => 200
        ], 200);
    }
}
