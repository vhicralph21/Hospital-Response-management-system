<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\EmergencyReport;
use Illuminate\Support\Facades\Validator;

class PatientController extends Controller
{
    /**
     * Create a new patient record.
     */
    public function savePatient(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string|max:100',
            'lastname' => 'required|string|max:100',
            'gender' => 'required|string|in:M,F,O',
            'phone' => 'nullable|string|max:20',
            'dob' => 'nullable|date',
            'blood_type' => 'nullable|string|max:10',
            'heart_rate' => 'nullable|numeric',
            'blood_pressure' => 'nullable|string|max:20',
            'respiratory_rate' => 'nullable|numeric',
            'pulse' => 'nullable|numeric',
            'temperature' => 'nullable|numeric',
            'allergies' => 'nullable|string|max:255',
            'emergency_contact_name' => 'nullable|string|max:100',
            'emergency_contact_phone' => 'nullable|string|max:20',
            'emergency_report_id' => 'required|string|exists:emergency_reports,report_id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $patient = Patient::create($validator->validated());

        return response()->json([
            'success' => true,
            'message' => 'Patient added successfully',
            'data' => $patient,
        ], 201);
    }

    /**
     * List all patients for a specific emergency report
     */
    public function getByReport($reportId)
    {
        $report = EmergencyReport::with('patients')->find($reportId);

        if (!$report) {
            return response()->json([
                'success' => false,
                'message' => 'Emergency report not found',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Patients retrieved successfully',
            'data' => $report->patients,
        ], 200);
    }
    /**
     * Update an existing patient record
     */
    public function UpdatePatient(Request $request)
    {
        $patientId = $request->patient_id;
        $patient = Patient::find($patientId);

        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'firstname' => 'sometimes|string|max:100',
            'lastname' => 'sometimes|string|max:100',
            'gender' => 'sometimes|string|in:M,F,O',
            'phone' => 'nullable|string|max:20',
            'dob' => 'nullable|date',
            'blood_type' => 'nullable|string|max:10',
            'heart_rate' => 'nullable|numeric',
            'blood_pressure' => 'nullable|string|max:20',
            'respiratory_rate' => 'nullable|numeric',
            'pulse' => 'nullable|numeric',
            'temperature' => 'nullable|numeric',
            'allergies' => 'nullable|string|max:255',
            'emergency_contact_name' => 'nullable|string|max:100',
            'emergency_contact_phone' => 'nullable|string|max:20',
            'emergency_report_id' => 'nullable|string|exists:emergency_reports,report_id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        $patient->update($validator->validated());

        return response()->json([
            'success' => true,
            'message' => 'Patient updated successfully',
            'data' => $patient,
        ], 200);
    }

    /**
     * Get a single patient by ID (with emergency report details)
     */
    public function getPatient(Request $request)
    {
        $patientId = $request->patient_id;
        $patient = Patient::with('emergencyReport')->find($patientId);

        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient not found',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $patient,
        ], 200);
    }

    /**
     * Get all patients
     */

    public function getAllPatients(Request $request)
    {
        try {
            $patients = Patient::orderBy('created_at', 'desc')->get();

            return response()->json([
                'success' => true,
                'message' => 'All patients retrieved successfully.',
                'data' => $patients,
                'code' => 200
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to fetch patients.',
                'details' => $e->getMessage(),
                'code' => 500
            ], 500);
        }
    }

    /**
     * Delete a patient record (soft delete)
     */
    public function destroy($patientId)
    {
        $patient = Patient::find($patientId);

        if (!$patient) {
            return response()->json([
                'success' => false,
                'message' => 'Patient not found',
            ], 404);
        }

        $patient->delete();

        return response()->json([
            'success' => true,
            'message' => 'Patient deleted successfully',
        ], 200);
    }
}
