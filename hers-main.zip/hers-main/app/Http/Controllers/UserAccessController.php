<?php

namespace App\Http\Controllers;

use App\Models\UserAccess;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class UserAccessController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): JsonResponse
    {
        $userAccess = UserAccess::with('user')->get();
        return response()->json(['data' => $userAccess], 200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'role' => 'required|in:user,staff,admin',
            'password' => 'required|string|min:8',
            'usercode' => 'required|exists:users,usercode',
        ]);

        $validated['password'] = bcrypt($validated['password']);
        $userAccess = UserAccess::create($validated);
        return response()->json(['data' => $userAccess, 'message' => 'User access created successfully'], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $uaccesscode): JsonResponse
    {
        $userAccess = UserAccess::with('user')->findOrFail($uaccesscode);
        return response()->json(['data' => $userAccess], 200);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $uaccesscode): JsonResponse
    {
        $userAccess = UserAccess::findOrFail($uaccesscode);

        $validated = $request->validate([
            'role' => 'sometimes|in:user,staff,admin',
            'password' => 'sometimes|string|min:8',
            'usercode' => 'sometimes|exists:users,usercode',
        ]);

        if (isset($validated['password'])) {
            $validated['password'] = bcrypt($validated['password']);
        }

        $userAccess->update($validated);
        return response()->json(['data' => $userAccess, 'message' => 'User access updated successfully'], 200);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $uaccesscode): JsonResponse
    {
        $userAccess = UserAccess::findOrFail($uaccesscode);
        $userAccess->delete();
        return response()->json(['message' => 'User access soft deleted successfully'], 200);
    }
}
