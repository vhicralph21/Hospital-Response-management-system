<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserAccess;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Get all users
     */
    public function getAllUsers(Request $request)
    {
        try {
            $authUser = auth()->user();

            if (!$authUser || !$authUser->access || $authUser->access->role !== 'admin') {
                return response()->json([
                    'success' => false,
                    'error' => 'Unauthorized access. Only admin users can view all users.',
                    'code' => 403
                ], 403);
            }

            $users = User::with('access')
                ->whereNull('deleted_at')
                ->orderBy('created_at', 'desc')
                ->get()
                ->map(function ($user) {
                    return [
                        'usercode' => $user->usercode,
                        'firstname' => $user->firstname,
                        'lastname' => $user->lastname,
                        'email' => $user->email,
                        'phone' => $user->phone,
                        'gender' => $user->gender,
                        'role' => $user->access->role ?? 'N/A',
                        'is_admin' => isset($user->userAccess->role) && $user->userAccess->role === 'admin',
                        'created_at' => $user->created_at,
                    ];
                });

            return response()->json([
                'success' => true,
                'message' => 'All users retrieved successfully.',
                'data' => $users,
                'code' => 200
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Failed to fetch users.',
                'details' => $e->getMessage(),
                'code' => 500
            ], 500);
        }
    }


    /**
     * Get a single user by usercode
     */
    public function getUser(Request $request)
    {
        $usercode = $request->usercode;
        $user = User::with('access')->where('usercode', $usercode)->first();

        if (!$user) {
            return response()->json([
                'success' => false,
                'error' => 'User not found',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'User retrieved successfully',
            'user' => $user
        ], 200);
    }

    /**
     * Update user details across affected tables
     */
    public function updateUser(Request $request)
    {
        $usercode = $request->usercode;
        $user = User::with('access')->where('usercode', $usercode)->first();
        if (!$user) {
            return response()->json([
                'success' => false,
                'error' => 'User not found',
            ], 404);
        }

        $validated = $request->validate([
            'firstname' => 'required|string|max:50',
            'lastname' => 'required|string|max:50',
            'gender' => 'required|in:M,F,O',
            'phone' => [
                'required', 'string', 'max:15',
                Rule::unique('users', 'phone')->ignore($user->usercode, 'usercode'),
            ],
            'email' => [
                'required', 'email', 'max:100',
                Rule::unique('users', 'email')->ignore($user->usercode, 'usercode'),
            ],
        ]);

        $user->update($validated);

        if ($user->userAccess) {
            $user->userAccess->touch();
        }

        return response()->json([
            'success' => true,
            'message' => 'User updated successfully',
            'user' => $user->fresh('access'),
        ], 200);
    }

    /**
     * Delete a user
     */
    public function destroyUser(Request $request)
    {
        $usercode = $request->usercode;
        $user = User::where('usercode', $usercode)->first();

        if (!$user) {
            return response()->json([
                'success' => false,
                'error' => 'User not found',
            ], 404);
        }

        $user->delete();

        return response()->json([
            'success' => true,
            'message' => 'User deleted successfully',
        ], 200);
    }

    /**
     * Promote user to admin
     */
    public function updateRole(Request $request)
    {
        $usercode = $request->usercode;
        $role = $request->role ?? 'admin';

        $user = UserAccess::where('usercode', $usercode)->first();

        if (!$user) {
            return response()->json([
                'success' => false,
                'error' => 'User not found',
            ], 404);
        }

        $user->role = $role;
        $user->save();

        return response()->json([
            'success' => true,
            'message' => "{$user->firstname} {$user->lastname} is now {$role}.",
            'data' => $user
        ], 200);
    }

    /**
     * Demote admin to staff
     */
    public function revokeRole(Request $request)
    {
        $usercode = $request->usercode;
        $user = UserAccess::where('usercode', $usercode)->first();

        if (!$user) {
            return response()->json([
                'success' => false,
                'error' => 'User not found',
            ], 404);
        }

        $user->role = 'staff';
        $user->save();

        return response()->json([
            'success' => true,
            'message' => "{$user->firstname} {$user->lastname} has been demoted to staff.",
            'data' => $user
        ], 200);
    }

    /**
     * Change user password
     */

    public function changePassword(Request $request)
    {
        $user = auth()->user();

        Log::info("the user is ".$user);

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized user.',
            ], 401);
        }

        $validator = Validator::make($request->all(), [
            'current_password' => 'required|string',
            'new_password' => 'required|string|min:8|confirmed',
        ]);

        if ($validator->fails()) {
            // Get the first validation error message
            $firstError = $validator->errors()->first();

            return response()->json([
                'success' => false,
                'message' => $firstError, // single error message for frontend toast
            ], 422);
        }

        $access = $user->access;

        if (!$access) {
            return response()->json([
                'success' => false,
                'message' => 'User access record not found.',
            ], 404);
        }

        if (!Hash::check($request->current_password, $access->password)) {
            return response()->json([
                'success' => false,
                'message' => 'Current password is incorrect.',
            ], 401);
        }

        $access->password = Hash::make($request->new_password);
        $access->save();

        return response()->json([
            'success' => true,
            'message' => 'Password changed successfully.',
        ], 200);
    }
}
