<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmergencyReport extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'emergency_reports';
    protected $primaryKey = 'report_id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'type',
        'severity',
        'number_of_victims',
        'description',
        'location',
        'location_lat',
        'location_lng',
        'status',
        'reported_by',
    ];

    protected $dates = ['deleted_at'];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->report_id)) {
                $lastReport = EmergencyReport::latest('report_id')->first();
                $nextId = $lastReport ? intval(substr($lastReport->report_id, 3)) + 1 : 1;
                $model->report_id = 'REP' . str_pad($nextId, 5, '0', STR_PAD_LEFT);
            }
        });
    }

    public function reporter()
    {
        return $this->belongsTo(User::class, 'reported_by', 'usercode');
    }

    public function patients()
    {
        return $this->hasMany(Patient::class, 'emergency_report_id', 'report_id');
    }
}
