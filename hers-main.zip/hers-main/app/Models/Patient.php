<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Patient extends Model
{
    use SoftDeletes;

    protected $table = 'patients';
    protected $primaryKey = 'patient_id';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = [
        'firstname',
        'lastname',
        'gender',
        'phone',
        'dob',
        'blood_type',
        'heart_rate',
        'blood_pressure',
        'respiratory_rate',
        'pulse',
        'temperature',
        'allergies',
        'emergency_contact_name',
        'emergency_contact_phone',
        'emergency_report_id',
    ];
    protected $dates = ['deleted_at', 'dob'];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->patient_id)) {
                $lastPatient = Patient::latest('patient_id')->first();
                $nextId = $lastPatient ? intval(substr($lastPatient->patient_id, 3)) + 1 : 1;
                $model->patient_id = 'PAT' . str_pad($nextId, 5, '0', STR_PAD_LEFT);
            }
        });
    }

    public function emergencyReport()
    {
        return $this->belongsTo(EmergencyReport::class, 'emergency_report_id', 'report_id');
    }
}
