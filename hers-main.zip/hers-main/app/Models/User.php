<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasApiTokens, SoftDeletes, Notifiable;

    protected $table = 'users';
    protected $primaryKey = 'usercode';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'firstname',
        'lastname',
        'gender',
        'phone',
        'email',
    ];

    protected $hidden = [
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->usercode)) {
                $lastUser = static::latest('usercode')->first();
                $nextId = $lastUser ? intval(substr($lastUser->usercode, 3)) + 1 : 1;
                $model->usercode = 'USR' . str_pad($nextId, 5, '0', STR_PAD_LEFT);
            }
        });
    }

    /** Relationships */
    public function access()
    {
        return $this->hasOne(UserAccess::class, 'usercode', 'usercode');
    }

    public function reports()
    {
        return $this->hasMany(EmergencyReport::class, 'reported_by', 'usercode');
    }

    /** Full name accessor */
    public function getFullNameAttribute()
    {
        return "{$this->firstname} {$this->lastname}";
    }
}
