<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Hash;

class UserAccess extends Model
{
    use SoftDeletes;

    protected $table = 'user_access';
    protected $primaryKey = 'uaccesscode';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'role',
        'password',
        'usercode',
    ];

    protected $hidden = [
        'password',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->uaccesscode)) {
                $lastAccess = static::latest('uaccesscode')->first();
                $nextId = $lastAccess ? intval(substr($lastAccess->uaccesscode, 3)) + 1 : 1;
                $model->uaccesscode = 'ACC' . str_pad($nextId, 5, '0', STR_PAD_LEFT);
            }

            // Automatically hash password if not already hashed
            if (!empty($model->password) && !preg_match('/^\$2y\$/', $model->password)) {
                $model->password = Hash::make($model->password);
            }
        });

        static::updating(function ($model) {
            if (!empty($model->password) && !preg_match('/^\$2y\$/', $model->password)) {
                $model->password = Hash::make($model->password);
            }
        });
    }

    /** Relationships */
    public function userAcess()
    {
        return $this->belongsTo(User::class, 'usercode', 'usercode');
    }
}
