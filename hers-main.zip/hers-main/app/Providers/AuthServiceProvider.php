<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [
        // Define policies here if needed
    ];

    public function boot()
    {
        $this->registerPolicies();

        Gate::define('view-user', function (User $user, $targetUser) {
            $userRole = $user->userAccess->role;
            return $userRole === 'admin' || $user->usercode === $targetUser->usercode;
        });

        Gate::define('manage-user', function (User $user) {
            return $user->userAccess->role === 'admin';
        });

        Gate::define('manage-emergency-report', function (User $user) {
            return in_array($user->userAccess->role, ['staff', 'admin']);
        });
    }
}
