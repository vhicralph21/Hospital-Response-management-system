
-- Users table: Stores all users (patients, staff, admins)
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role ENUM('patient', 'staff', 'admin') NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL, -- Hashed password
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_role (role) -- For filtering by role
) ENGINE=InnoDB;

-- Patient Profiles: Stores patient-specific info (medical history, allergies, etc.)
CREATE TABLE patient_profiles (
    user_id BIGINT UNSIGNED PRIMARY KEY,
    medical_history TEXT, -- JSON or text for conditions
                                              allergies TEXT, -- JSON or text for allergies
                                                                                  emergency_contact_name VARCHAR(255),
                                                                                  emergency_contact_phone VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Emergency Reports: Stores accident/emergency reports
CREATE TABLE emergency_reports (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED, -- Patient who submitted the report
    type ENUM('accident', 'medical', 'other') NOT NULL,
    severity ENUM('critical', 'moderate', 'low') NOT NULL,
    description TEXT,
    location_lat DECIMAL(10, 8),
    location_lng DECIMAL(11, 8),
    media_urls TEXT, -- JSON array of S3 URLs or file paths
    status ENUM('pending', 'received', 'dispatched', 'resolved') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_status (status), -- For filtering active reports
INDEX idx_location (location_lat, location_lng) -- For geospatial queries
) ENGINE=InnoDB;

-- Ambulances: Stores ambulance details and availability
CREATE TABLE ambulances (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    license_plate VARCHAR(50) UNIQUE NOT NULL,
    status ENUM('available', 'in_use', 'maintenance') DEFAULT 'available',
    current_location_lat DECIMAL(10, 8),
    current_location_lng DECIMAL(11, 8),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status) -- For availability checks
) ENGINE=InnoDB;

-- Assignments: Links reports to ambulances and staff
CREATE TABLE assignments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    report_id BIGINT UNSIGNED NOT NULL,
    ambulance_id BIGINT UNSIGNED,
    staff_id BIGINT UNSIGNED, -- Staff assigned (optional for first responders)
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (report_id) REFERENCES emergency_reports(id) ON DELETE CASCADE,
    FOREIGN KEY (ambulance_id) REFERENCES ambulances(id) ON DELETE SET NULL,
    FOREIGN KEY (staff_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Tracking Logs: Stores real-time tracking updates for reports
                                                        CREATE TABLE tracking_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    report_id BIGINT UNSIGNED NOT NULL,
    status_update ENUM('received', 'dispatched', 'en_route', 'arrived', 'resolved') NOT NULL,
    location_lat DECIMAL(10, 8), -- Ambulance location at time of update
    location_lng DECIMAL(11, 8),
    eta_minutes INT, -- Estimated time of arrival
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (report_id) REFERENCES emergency_reports(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Admin Logs: Tracks system usage and admin actions
CREATE TABLE admin_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id BIGINT UNSIGNED NOT NULL,
    action VARCHAR(255) NOT NULL, -- e.g., 'updated_user', 'generated_report'
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


<?php

// Migration for users table
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->enum('role', ['patient', 'staff', 'admin'])->index();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('phone', 20)->nullable();
            $table->string('device_token', 255)->nullable();
            $table->timestamps();
        });
}

    public function down()
    {
        Schema::dropIfExists('users');
}
}

// Migration for patient_profiles table
class CreatePatientProfilesTable extends Migration
{
    public function up()
    {
        Schema::create('patient_profiles', function (Blueprint $table) {
            $table->bigInteger('user_id')->unsigned()->primary()->comment('Links to users table for patient-specific data');
            $table->text('medical_history')->nullable()->comment('Stores medical history (JSON or text) for emergency context, encrypted if needed');
            $table->text('allergies')->nullable()->comment('Stores allergies for quick reference by staff, encrypted if needed');
            $table->string('emergency_contact_name')->nullable()->comment('Name of emergency contact for patient outreach');
            $table->string('emergency_contact_phone', 20)->nullable()->comment('Phone number for emergency contact');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade')->comment('Ensures profile deletion if user is removed');
            $table->timestamps();
        });
}

    public function down()
    {
        Schema::dropIfExists('patient_profiles');
}
}

// Migration for emergency_reports table
class CreateEmergencyReportsTable extends Migration
{
    public function up()
    {
        Schema::create('emergency_reports', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('user_id')->unsigned()->nullable()->comment('Links to patient who submitted the report');
            $table->enum('type', ['accident', 'medical', 'other'])->comment('Supports real-time reporting by categorizing incidents');
            $table->enum('severity', ['critical', 'moderate', 'low'])->comment('Enables prioritization for efficient hospital monitoring');
            $table->integer('number_of_victims')->default(1)->comment('Added to assess severity and resource needs');
            $table->text('description')->nullable()->comment('Details of the incident for staff evaluation');
            $table->decimal('location_lat', 10, 8)->nullable()->comment('Accurate GPS latitude for location tracking');
            $table->decimal('location_lng', 11, 8)->nullable()->comment('Accurate GPS longitude for location tracking');
            $table->text('media_urls')->nullable()->comment('JSON array of photo/video URLs for evidence, stored securely');
            $table->enum('status', ['pending', 'received', 'dispatched', 'resolved'])->default('pending')->index()->comment('Tracks report progress for real-time updates');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('set null');
            $table->index(['location_lat', 'location_lng'])->comment('Optimizes geospatial queries for mapping');
            $table->timestamps();
        });
}

    public function down()
    {
        Schema::dropIfExists('emergency_reports');
}
}

// Migration for ambulances table
class CreateAmbulancesTable extends Migration
{
    public function up()
    {
        Schema::create('ambulances', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('license_plate', 50)->unique()->comment('Unique identifier for ambulance tracking');
            $table->enum('status', ['available', 'in_use', 'maintenance'])->default('available')->index()->comment('Supports resource allocation');
            $table->decimal('current_location_lat', 10, 8)->nullable()->comment('Real-time ambulance location for routing');
            $table->decimal('current_location_lng', 11, 8)->nullable()->comment('Real-time ambulance location for routing');
            $table->timestamps();
        });
}

    public function down()
    {
        Schema::dropIfExists('ambulances');
}
}

// Migration for assignments table
class CreateAssignmentsTable extends Migration
{
    public function up()
    {
        Schema::create('assignments', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('report_id')->unsigned()->comment('Links to emergency report for resource assignment');
            $table->bigInteger('ambulance_id')->unsigned()->nullable()->comment('Assigned ambulance, nullable if not yet assigned');
            $table->bigInteger('staff_id')->unsigned()->nullable()->comment('Assigned staff, nullable for flexibility');
            $table->timestamp('assigned_at')->useCurrent()->comment('Tracks when assignment was made for response time monitoring');
            $table->foreign('report_id')->references('id')->on('emergency_reports')->onDelete('cascade');
            $table->foreign('ambulance_id')->references('id')->on('ambulances')->onDelete('set null');
            $table->foreign('staff_id')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
        });
}

    public function down()
    {
        Schema::dropIfExists('assignments');
}
}

// Migration for tracking_logs table
class CreateTrackingLogsTable extends Migration
{
    public function up()
    {
        Schema::create('tracking_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('report_id')->unsigned()->comment('Links to emergency report for tracking updates');
            $table->enum('status_update', ['received', 'dispatched', 'en_route', 'arrived', 'resolved'])->comment('Real-time status for mobile app updates');
            $table->decimal('location_lat', 10, 8)->nullable()->comment('Ambulance location during update');
            $table->decimal('location_lng', 11, 8)->nullable()->comment('Ambulance location during update');
            $table->integer('eta_minutes')->nullable()->comment('Estimated arrival time for patient tracking');
            $table->timestamp('created_at')->useCurrent();
            $table->foreign('report_id')->references('id')->on('emergency_reports')->onDelete('cascade');
            $table->timestamps();
        });
}

    public function down()
    {
        Schema::dropIfExists('tracking_logs');
}
}

// Migration for admin_logs table
class CreateAdminLogsTable extends Migration
{
    public function up()
    {
        Schema::create('admin_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('admin_id')->unsigned()->comment('Links to admin user for auditing');
            $table->string('action', 255)->comment('Records actions like report generation or user management');
            $table->text('details')->nullable()->comment('Additional info for admin actions');
            $table->timestamp('created_at')->useCurrent();
            $table->foreign('admin_id')->references('id')->on('users')->onDelete('cascade');
            $table->timestamps();
        });
}

    public function down()
    {
        Schema::dropIfExists('admin_logs');
}
}

