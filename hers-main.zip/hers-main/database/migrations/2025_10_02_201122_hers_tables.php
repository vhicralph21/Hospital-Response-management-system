<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        // USERS TABLE
//
//        Schema::create('users', function (Blueprint $table) {
//            $table->string('usercode', 8)->primary();
//            $table->string('firstname', 50);
//            $table->string('lastname', 50);
//            $table->enum('gender', ['M', 'F', 'O'])->default('O');
//            $table->string('phone', 11)->nullable();
//            $table->string('email', 255)->unique()->index();
//            $table->timestamps();
//            $table->softDeletes();
//        });
//
//        // USER ACCESS TABLE
//        Schema::create('user_access', function (Blueprint $table) {
//            $table->string('uaccesscode', 8)->primary();
//            $table->enum('role', ['user', 'staff', 'admin'])->index();
//            $table->string('password', 255);
//            $table->string('usercode', 8)->index();
//            $table->timestamps();
//            $table->softDeletes();
//
//            // Foreign key
//            $table->foreign('usercode')
//                ->references('usercode')
//                ->on('users')
//                ->onDelete('restrict');
//        });
//
//        // EMERGENCY REPORTS TABLE (moved before patients)
//        Schema::create('emergency_reports', function (Blueprint $table) {
//            $table->string('report_id', 8)->primary();
//            $table->enum('type', ['accident', 'medical', 'other']);
//            $table->enum('severity', ['critical', 'moderate', 'low']);
//            $table->integer('number_of_victims')->default(1);
//            $table->text('description')->nullable();
//            $table->text('location')->nullable()->index('location');
//            $table->decimal('location_lat', 10, 8)->nullable();
//            $table->decimal('location_lng', 11, 8)->nullable();
//            $table->enum('status', ['pending', 'acknowledge', 'dispatched', 'resolved'])
//                ->default('pending')->index();
//            $table->string('reported_by', 8)->nullable()->index();
//            $table->timestamps();
//            $table->softDeletes();
//
//            // Foreign key
//            $table->foreign('reported_by')
//                ->references('usercode')
//                ->on('users')
//                ->onDelete('set null');
//        });
//
//        // PATIENTS TABLE
//        Schema::create('patients', function (Blueprint $table) {
//            $table->string('patient_id', 8)->primary();
//            $table->string('firstname', 50);
//            $table->string('lastname', 50);
//            $table->enum('gender', ['M', 'F', 'O'])->default('O');
//            $table->string('phone', 11)->nullable()->index();
//            $table->date('dob')->nullable();
//            $table->string('blood_type', 3)->nullable();
//            $table->decimal('heart_rate', 5, 2)->nullable();
//            $table->string('blood_pressure', 15)->nullable();
//            $table->decimal('respiratory_rate', 5, 2)->nullable();
//            $table->decimal('pulse', 5, 2)->nullable();
//            $table->decimal('temperature', 5, 2)->nullable();
//            $table->text('allergies')->nullable();
//            $table->string('emergency_contact_name', 100)->nullable();
//            $table->string('emergency_contact_phone', 20)->nullable()->index();
//            $table->string('emergency_report_id', 8)->nullable()->index();
//            $table->timestamps();
//            $table->softDeletes();
//
//            // Foreign key
//            $table->foreign('emergency_report_id')
//                ->references('report_id')
//                ->on('emergency_reports')
//                ->onDelete('cascade');
//        });
    }

    public function down()
    {
//        Schema::dropIfExists('patients');
//        Schema::dropIfExists('emergency_reports');
//        Schema::dropIfExists('user_access');
//        Schema::dropIfExists('users');
    }
};
