<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class hers_tables_seeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // Generate usercode manually
        $usercodes = ['USR00001'];

        // Seed users table
        $users = [
            [
                'usercode' => $usercodes[0],
                'firstname' => 'Admin',
                'lastname' => 'User',
                'gender' => 'O',
                'phone' => null,
                'email' => 'admin.user@example.com',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        DB::table('users')->insert($users);

        // Seed user_access table
        DB::table('user_access')->insert([
            [
                'uaccesscode' => 'ACC00001',
                'role' => 'user',
                'password' => bcrypt('password123'),
                'usercode' => $usercodes[0],
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        // Seed emergency_reports table
        $reportIds = ['REP00001', 'REP00002'];
        DB::table('emergency_reports')->insert([
            [
                'report_id' => $reportIds[0],
                'type' => 'accident',
                'severity' => 'critical',
                'number_of_victims' => 2,
                'description' => 'Car accident on main highway',
                'location' => 'Main Highway, Abuja',
                'location_lat' => 9.0765,
                'location_lng' => 7.3986,
                'status' => 'pending',
                'reported_by' => $usercodes[0],
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'report_id' => $reportIds[1],
                'type' => 'medical',
                'severity' => 'moderate',
                'number_of_victims' => 1,
                'description' => 'Heart attack reported',
                'location' => 'Central Hospital, Lagos',
                'location_lat' => 6.5244,
                'location_lng' => 3.3792,
                'status' => 'acknowledge',
                'reported_by' => $usercodes[0],
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        // Seed patients table
        DB::table('patients')->insert([
            [
                'patient_id' => 'PAT00001',
                'firstname' => 'Michael',
                'lastname' => 'Johnson',
                'gender' => 'M',
                'phone' => '08123456789',
                'dob' => '1990-05-15',
                'blood_type' => 'A+',
                'heart_rate' => 75.5,
                'blood_pressure' => '120/80',
                'respiratory_rate' => 16.0,
                'pulse' => 72.0,
                'temperature' => 36.8,
                'allergies' => 'Penicillin',
                'emergency_contact_name' => 'Sarah Johnson',
                'emergency_contact_phone' => '09098765432',
                'emergency_report_id' => $reportIds[0],
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'patient_id' => 'PAT00002',
                'firstname' => 'Emily',
                'lastname' => 'Brown',
                'gender' => 'F',
                'phone' => '08134567890',
                'dob' => '1985-09-22',
                'blood_type' => 'O-',
                'heart_rate' => 80.0,
                'blood_pressure' => '130/85',
                'respiratory_rate' => 18.0,
                'pulse' => 78.0,
                'temperature' => 37.0,
                'allergies' => null,
                'emergency_contact_name' => 'David Brown',
                'emergency_contact_phone' => '09087654321',
                'emergency_report_id' => $reportIds[1],
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
