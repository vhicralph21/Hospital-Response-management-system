<?php

use App\Http\Controllers\UserController;
use App\Http\Controllers\UserAccessController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\EmergencyReportController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;

//Route::prefix('auth')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/get-all-users', [UserController::class, 'getAllUsers']);
        Route::get('/get-user', [UserController::class, 'getUser']);
        Route::post('/update-user', [UserController::class, 'updateUser']);
        Route::post('/delete-user', [UserController::class, 'destroyUser']);
        Route::post('/update-role', [UserController::class, 'updateRole']);
        Route::post('/revoke-role', [UserController::class, 'revokeRole']);
        Route::post('/change-password', [UserController::class, 'changePassword']);
        Route::post('/save-patient', [PatientController::class, 'savePatient']);
        Route::post('/update-patient', [PatientController::class, 'UpdatePatient']);
        Route::get('/get-patient', [PatientController::class, 'getPatient']);
        Route::get('/get-all-patients', [PatientController::class, 'getAllPatients']);
        Route::get('/patients-by-report', [PatientController::class, 'getByReport']);
        Route::post('/send-report', [EmergencyReportController::class, 'sendReport']);
        Route::get('/my-reports', [EmergencyReportController::class, 'myReports']);
        Route::get('/get-report', [EmergencyReportController::class, 'getReport']);
        Route::get('/get-all-reports', [EmergencyReportController::class, 'getAllReports']);
        Route::post('/update-report-status', [EmergencyReportController::class, 'updateStatus']);


    });
//});

